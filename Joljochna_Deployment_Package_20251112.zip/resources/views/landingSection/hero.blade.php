<section id="home" class="hero">
    <style>
        /* Full-bleed hero slider - FORCE FULL WIDTH */
        html {
            overflow-x: hidden;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%
        }

        body {
            overflow-x: hidden !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100vw !important;
            max-width: 100vw !important;
            position: relative !important
        }

        body #home.hero {
            min-height: 92vh !important;
            height: 92vh !important;
            margin: 0 !important;
            padding: 0 !important;
            max-width: none !important;
            width: 100vw !important;
            position: relative !important;
            background: transparent !important;
            display: block !important;
            align-items: unset !important;
            justify-content: unset !important;
            left: 0 !important;
            transform: none !important;
            overflow: hidden !important
        }

        #home {
            position: relative !important;
            padding: 0 !important;
            margin: 0 auto 0 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            left: 0 !important;
            right: 0 !important;
            box-sizing: border-box !important;
            transform: none !important;
            min-height: 92vh !important;
            height: 92vh !important;
            overflow: hidden !important;
            float: none !important;
            clear: both !important
        }

        /* Break out of ANY container - ULTRA AGGRESSIVE */
        #home:before,
        #home:after {
            content: "";
            display: table;
            clear: both
        }

        section#home.hero {
            width: 100vw !important;
            max-width: 100vw !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: hidden !important;
            position: relative !important;
            min-height: 92vh !important;
            height: 92vh !important
        }

        #home .slider-wrap {
            position: absolute !important;
            width: 100vw !important;
            height: 92vh;
            min-height: 360px;
            max-height: none;
            overflow: hidden !important;
            margin: 0 !important;
            padding: 0 !important;
            left: 0 !important;
            right: 0 !important;
            top: 0 !important;
            max-width: 100vw !important
        }

        #home .slides {
            position: absolute !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            height: 100% !important;
            background: #0b3a28;
            top: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            max-width: 100% !important
        }

        #home .slides img {
            position: absolute !important;
            inset: 0 !important;
            width: 100% !important;
            height: 100% !important;
            object-fit: cover;
            opacity: 0;
            transition: opacity .6s ease;
            left: 0 !important;
            right: 0 !important;
            margin: 0 !important
        }

        #home .slides img.active {
            opacity: 1
        }

        /* Professional Overlay with Full Width Breakout */
        #home .overlay {
            position: absolute !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            height: 100% !important;
            top: 0 !important;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: clamp(20px, 4vw, 40px);
            z-index: 2;
            box-sizing: border-box;
            margin: 0 !important;
            max-width: 100% !important
        }

        #home .overlay::before {
            content: "";
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(10, 77, 46, .75) 0%, rgba(0, 0, 0, .55) 100%);
            z-index: 0
        }

        #home .overlay::after {
            content: "";
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at center, transparent 0%, rgba(0, 0, 0, .3) 100%);
            z-index: 0
        }

        #home .overlay-content {
            position: relative;
            z-index: 1;
            text-align: center;
            color: #fff;
            max-width: min(1200px, 90vw);
            width: 100%;
            padding: clamp(16px, 3vw, 32px);
            margin: 0 auto;
            backdrop-filter: blur(2px);
            border-radius: 16px
        }

        /* Professional Typography - Fluid & Responsive */
        body #home .overlay-content h1 {
            font-size: clamp(26px, 5.5vw, 62px) !important;
            line-height: 1.1 !important;
            font-weight: 800 !important;
            margin: 0 0 clamp(11px, 1.8vw, 18px) !important;
            letter-spacing: -0.02em !important;
            text-shadow: 0 4px 12px rgba(0, 0, 0, .5), 0 2px 4px rgba(0, 0, 0, .3);
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.2s;
            opacity: 0
        }

        body #home .overlay-content h2 {
            font-size: clamp(18px, 3.5vw, 34px) !important;
            line-height: 1.2 !important;
            font-weight: 700 !important;
            margin: 0 0 clamp(12px, 2.2vw, 20px) !important;
            letter-spacing: -0.01em !important;
            text-shadow: 0 3px 10px rgba(0, 0, 0, .4), 0 1px 3px rgba(0, 0, 0, .3);
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.4s;
            opacity: 0
        }

        body #home .overlay-content .hero-subtitle {
            opacity: 0;
            margin-bottom: clamp(18px, 2.7vw, 28px) !important;
            font-size: clamp(14px, 2.2vw, 18px) !important;
            line-height: 1.5 !important;
            text-shadow: 0 2px 8px rgba(0, 0, 0, .4);
            font-weight: 500;
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.6s
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px)
            }

            to {
                opacity: 1;
                transform: translateY(0)
            }
        }

        /* Professional CTA Buttons */
        body #home .overlay-content .cta-buttons {
            display: flex;
            gap: clamp(12px, 2vw, 20px);
            justify-content: center;
            flex-wrap: wrap;
            align-items: center;
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.8s;
            opacity: 0
        }

        body #home .overlay-content .btn {
            padding: clamp(9px, 1.3vw, 13px) clamp(18px, 2.7vw, 28px) !important;
            border-radius: 9999px !important;
            font-weight: 700 !important;
            letter-spacing: .3px !important;
            font-size: clamp(13px, 1.6vw, 16px) !important;
            min-height: clamp(40px, 5.5vw, 48px) !important;
            transition: all .3s cubic-bezier(.4, 0, .2, 1);
            text-decoration: none !important;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            white-space: nowrap
        }

        #home .overlay-content .btn-primary {
            background: linear-gradient(135deg, #16a34a, #22c55e);
            color: #ffffff;
            border: 1px solid rgba(255, 255, 255, .18);
            box-shadow: 0 10px 24px rgba(34, 197, 94, .32)
        }

        #home .overlay-content .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 30px rgba(34, 197, 94, .4);
            filter: saturate(1.05)
        }

        #home .overlay-content .btn-primary:active {
            transform: translateY(0);
            box-shadow: 0 6px 16px rgba(34, 197, 94, .3)
        }

        #home .overlay-content .btn-primary:focus {
            outline: 2px solid rgba(34, 197, 0, .85);
            outline-offset: 2px
        }

        /* Yellow, modern, smooth button for Contact */
        #home .overlay-content .btn-secondary {
            background: linear-gradient(135deg, #ffd700, #ffea7a);
            color: #0f172a;
            border: 1px solid rgba(255, 255, 255, .18);
            box-shadow: 0 10px 24px rgba(255, 215, 0, .32)
        }

        #home .overlay-content .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 30px rgba(255, 215, 0, .4);
            filter: saturate(1.05)
        }

        #home .overlay-content .btn-secondary:active {
            transform: translateY(0);
            box-shadow: 0 6px 16px rgba(255, 215, 0, .3)
        }

        #home .overlay-content .btn-secondary:focus {
            outline: 2px solid rgba(255, 215, 0, .8);
            outline-offset: 2px
        }

        #home .slider-controls {
            position: absolute !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            height: 100% !important;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            pointer-events: none;
            z-index: 3;
            margin: 0 !important;
            top: 0 !important;
            max-width: 100% !important
        }

        #home .slider-btn {
            pointer-events: auto;
            background: rgba(0, 0, 0, .45);
            color: #fff;
            border: none;
            width: 42px;
            height: 42px;
            border-radius: 999px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease
        }

        #home .slider-btn:hover {
            background: rgba(0, 0, 0, .65);
            transform: scale(1.1)
        }

        #home .slider-dots {
            position: absolute;
            bottom: 14px;
            left: 0;
            right: 0;
            display: flex;
            justify-content: center;
            gap: 8px;
            z-index: 2
        }

        #home .slider-dot {
            width: 10px;
            height: 10px;
            border-radius: 999px;
            background: rgba(255, 255, 255, .5);
            cursor: pointer
        }

        #home .slider-dot.active {
            background: #ffd700
        }

        /* Green Wave Shape at Bottom */
        #home::after {
            content: "";
            position: absolute;
            bottom: -1px;
            left: 0;
            right: 0;
            width: 100%;
            height: 150px;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none"><defs><linearGradient id="roadGrad" x1="0%25" y1="0%25" x2="0%25" y2="100%25"><stop offset="0%25" style="stop-color:%230a4d2e;stop-opacity:1" /><stop offset="50%25" style="stop-color:%23166534;stop-opacity:1" /><stop offset="100%25" style="stop-color:%230a3d24;stop-opacity:1" /></linearGradient></defs><path d="M0,0 C150,100 350,0 600,50 C850,100 1050,0 1200,50 L1200,120 L0,120 Z" fill="url(%23roadGrad)" opacity="0.95"/><path d="M0,15 C150,90 350,5 600,45 C850,90 1050,5 1200,45" stroke="%23ffeb3b" stroke-width="4" fill="none" stroke-dasharray="30,20" opacity="0.85"/><path d="M0,2 C150,95 350,-5 600,42 C850,95 1050,-5 1200,42" stroke="%23ffffff" stroke-width="2.5" fill="none" opacity="0.4"/><path d="M0,28 C150,105 350,15 600,58 C850,105 1050,15 1200,58" stroke="%23ffffff" stroke-width="2.5" fill="none" opacity="0.4"/></svg>') no-repeat center bottom;
            background-size: cover;
            z-index: 4;
            pointer-events: none
        }

        /* Green Shape Below Hero */
        .green-shape-bottom {
            width: 100%;
            height: 200px;
            background: linear-gradient(180deg, #0a3d24 0%, #166534 50%, #0a4d2e 100%);
            position: relative;
            margin-top: -90px;
            padding: 0;
            overflow: hidden;
            z-index: 1;
        }

        #home .scroll-indicator {
            display: flex;
            justify-content: center;
            margin-top: clamp(67px, 4vw, 83px);
            position: relative;
            z-index: 1
        }

        /* Building on Road */
        #home .building-side {
            position: absolute;
            bottom: 40px;
            right: 100px;
            width: 250px;
            height: 300px;
            z-index: 4;
            opacity: 0.9
        }

        /* Car Animation on Road */
        #home .car-animation {
            position: absolute;
            bottom: 25px;
            left: -150px;
            width: 120px;
            height: auto;
            z-index: 5;
            animation: carDrive 20s linear infinite;
            filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.3));
        }

        @keyframes carDrive {
            0% {
                left: -150px;
                transform: translateX(0);
            }
            100% {
                left: 100%;
                transform: translateX(150px);
            }
        }

        /* Tablet and small desktop responsive */
        @media (max-width: 1024px) {
            #home .slider-controls {
                padding: 0 16px
            }

            #home .slider-btn {
                width: 38px;
                height: 38px;
                font-size: 18px
            }
        }

        /* Large Desktop */
        @media (min-width: 1440px) {
            #home .overlay {
                padding: 48px
            }

            #home .overlay-content {
                max-width: 1400px;
                padding: 40px
            }
        }

        /* Tablet responsive */
        @media (max-width: 768px) {
            .green-shape-bottom {
                display: none;
            }

            body #home.hero,
            #home,
            section#home.hero {
                min-height: 70vh !important;
                height: 70vh !important;
            }

            body #home .slider-wrap {
                height: 100%;
            }

            #home .overlay {
                align-items: center;
                justify-content: center;
                padding: clamp(16px, 3vw, 28px);
                padding-top: 80px;
            }

            #home .overlay-content {
                padding: clamp(12px, 2.5vw, 24px);
                border-radius: 12px
            }

            body #home .overlay-content h1 {
                text-shadow: 0 3px 10px rgba(0, 0, 0, .6)
            }

            body #home .overlay-content h2 {
                text-shadow: 0 2px 8px rgba(0, 0, 0, .5)
            }

            body #home .overlay-content .cta-buttons {
                gap: clamp(10px, 2vw, 14px);
                row-gap: clamp(10px, 2vw, 14px);
                flex-direction: row
            }

            body #home .overlay-content .btn {
                width: auto;
                max-width: none;
                min-width: clamp(120px, 30vw, 160px)
            }

            #home .slider-controls {
                padding: 0 12px
            }

            #home .slider-btn {
                width: 34px;
                height: 34px;
                font-size: 16px;
                background: rgba(0, 0, 0, .6)
            }

            #home .slider-dots {
                bottom: 12px;
                gap: 6px
            }

            #home .slider-dot {
                width: 8px;
                height: 8px
            }

            #home::after {
                height: 100px
            }

            #home .building-side {
                bottom: -10px;
                right: 70px;
                width: 210px;
                height: 250px
            }

            #home .car-animation {
                bottom: 20px;
                width: 90px;
            }

            #home .scroll-indicator {
                margin-top: clamp(59px, 3vw, 71px)
            }
        }

        /* Mobile landscape and small tablets */
        @media (max-width: 640px) {
            body #home.hero,
            #home,
            section#home.hero {
                min-height: 72vh !important;
                height: 72vh !important;
            }

            #home .overlay {
                padding-top: 70px;
            }

            #home .slider-controls {
                padding: 0 8px
            }

            #home .slider-btn {
                width: 32px;
                height: 32px;
                font-size: 14px
            }

            #home .slider-dots {
                bottom: 10px;
                gap: 5px
            }

            #home .slider-dot {
                width: 7px;
                height: 7px
            }
        }

        /* Mobile portrait */
        @media (max-width: 480px) {
            .green-shape-bottom {
                display: none;
            }

            body #home.hero,
            #home,
            section#home.hero {
                min-height: 75vh !important;
                height: 75vh !important;
            }

            body #home .slider-wrap {
                height: 100%;
                min-height: 450px
            }

            #home .overlay {
                align-items: center;
                justify-content: center;
                padding: 16px 12px;
                padding-top: 100px;
            }

            #home .overlay-content {
                padding: 16px 12px;
                max-width: 95vw;
                border-radius: 10px
            }

            body #home .overlay-content h1 {
                font-size: clamp(26px, 7vw, 36px) !important;
                line-height: 1.2 !important;
                margin-bottom: 14px !important;
                text-shadow: 0 3px 10px rgba(0, 0, 0, .8)
            }

            body #home .overlay-content h2 {
                font-size: clamp(20px, 5.5vw, 28px) !important;
                line-height: 1.3 !important;
                margin-bottom: 16px !important;
                text-shadow: 0 2px 8px rgba(0, 0, 0, .7)
            }

            body #home .overlay-content .hero-subtitle {
                font-size: clamp(15px, 4vw, 17px) !important;
                margin-bottom: 20px !important;
                line-height: 1.5 !important
            }

            body #home .overlay-content .cta-buttons {
                gap: 10px;
                flex-direction: column;
                width: 100%;
                max-width: 280px;
                margin: 0 auto
            }

            body #home .overlay-content .btn {
                width: 100% !important;
                padding: 12px 20px !important;
                min-height: 46px !important;
                font-size: 15px !important;
                max-width: 100%
            }

            /* Smaller slider controls on mobile */
            #home .slider-controls {
                padding: 0 6px
            }

            #home .slider-btn {
                width: 28px;
                height: 28px;
                font-size: 12px;
                background: rgba(0, 0, 0, .7)
            }

            #home .slider-dots {
                bottom: 8px;
                gap: 4px
            }

            #home .slider-dot {
                width: 6px;
                height: 6px
            }

            #home::after {
                height: 80px
            }

            #home .building-side {
                bottom: -30px;
                right: 50px;
                width: 190px;
                height: 220px
            }

            #home .car-animation {
                bottom: 15px;
                width: 70px;
                animation: carDrive 18s linear infinite;
            }

            #home .scroll-indicator {
                margin-top: 59px;
                transform: scale(0.85)
            }
        }

        /* Extra small mobile */
        @media (max-width: 375px) {
            body #home.hero,
            #home,
            section#home.hero {
                min-height: 80vh !important;
                height: 80vh !important;
            }

            #home .overlay {
                padding-top: 120px;
            }

            #home .slider-controls {
                padding: 0 4px
            }

            #home .slider-btn {
                width: 26px;
                height: 26px;
                font-size: 11px
            }
        }

        /* Mobile landscape mode - focus on text */
        @media (max-width: 896px) and (orientation: landscape) {
            body #home.hero,
            #home,
            section#home.hero {
                min-height: 100vh !important;
                height: 100vh !important;
            }

            #home .overlay {
                padding: 20px 12px;
                align-items: center;
            }

            #home .overlay-content {
                padding: 12px;
            }

            body #home .overlay-content h1 {
                font-size: clamp(24px, 5vw, 32px) !important;
                margin-bottom: 10px !important;
            }

            body #home .overlay-content h2 {
                font-size: clamp(18px, 4vw, 24px) !important;
                margin-bottom: 12px !important;
            }

            body #home .overlay-content .hero-subtitle {
                font-size: clamp(14px, 3vw, 16px) !important;
                margin-bottom: 16px !important;
            }

            #home .car-animation {
                bottom: 15px;
                width: 80px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            #home .slides img {
                transition: none
            }

            body #home .overlay-content .btn {
                transition: none
            }

            body #home .overlay-content h1,
            body #home .overlay-content h2,
            body #home .overlay-content .hero-subtitle,
            body #home .overlay-content .cta-buttons {
                animation: none !important;
                opacity: 1 !important
            }
        }
    </style>

    <div class="slider-wrap">
        <div class="slides" id="homeSlides">
            <!-- Slides will be loaded dynamically -->
        </div>
        <div class="overlay">
            <div class="overlay-content" id="heroContent">
                <h1 id="heroTitle">আপনার স্বপ্নের বাড়ি</h1>
                <h2 id="heroSubtitle">জলজোছনা প্রজেক্টে</h2>
                <p id="heroDesc" class="hero-subtitle">প্রকল্পের মূল্য তালিকা - বুকিং পরিমাণ: ১০,০০০ টাকা (কার্য প্রতি)
                </p>
                <div class="cta-buttons" id="heroButtons">
                    <a id="heroBtnPrimary" href="#pricing" class="btn btn-primary">মূল্য দেখুন</a>
                    <a id="heroBtnSecondary" href="#contact" class="btn btn-secondary">যোগাযোগ করুন</a>
                </div>
                <div class="scroll-indicator">
                    <span></span>
                </div>
            </div>
        </div>
        <div class="building-side">
            <img src="/images/Building 2.svg" alt="Building" style="width:100%; height:100%; object-fit:contain;">
        </div>
        <div class="car-animation">
            <img src="/images/car 2.gif" alt="Moving Car" style="width:100%; height:auto;">
        </div>
        <div class="slider-controls">
            <button class="slider-btn" id="homePrev" aria-label="Previous">❮</button>
            <button class="slider-btn" id="homeNext" aria-label="Next">❯</button>
        </div>
        <div class="slider-dots" id="homeDots"></div>
    </div>

    <script>
        (function () {
            let sliders = [];
            let currentSliderIndex = 0;
            let idx = 0, timer;
            const slidesContainer = document.getElementById('homeSlides');
            const dotsWrap = document.getElementById('homeDots');
            const prev = document.getElementById('homePrev');
            const next = document.getElementById('homeNext');
            const heroTitle = document.getElementById('heroTitle');
            const heroSubtitle = document.getElementById('heroSubtitle');
            const heroDesc = document.getElementById('heroDesc');
            const heroBtnPrimary = document.getElementById('heroBtnPrimary');
            const heroBtnSecondary = document.getElementById('heroBtnSecondary');

            async function loadHeroSliders() {
                try {
                    const response = await fetch('/api/hero-sliders');
                    if (!response.ok) throw new Error('Failed to load sliders');
                    sliders = await response.json();
                    
                    if (sliders.length === 0) {
                        // Fallback to default content
                        sliders = [{
                            id: 'default',
                            title: 'আপনার স্বপ্নের বাড়ি',
                            subtitle: 'জলজোছনা প্রজেক্টে',
                            description: 'প্রকল্পের মূল্য তালিকা - বুকিং পরিমাণ: ১০,০০০ টাকা (কার্য প্রতি)',
                            primary_button_text: 'মূল্য দেখুন',
                            primary_button_link: '#pricing',
                            secondary_button_text: 'যোগাযোগ করুন',
                            secondary_button_link: '#contact',
                            image_url: '/images/Ningbo-Green-Belt-05_.jpg'
                        }];
                    }
                    
                    renderSliders();
                    initSlider();
                } catch (error) {
                    console.error('Error loading hero sliders:', error);
                    // Use default content on error
                    renderDefaultSlider();
                }
            }

            function renderSliders() {
                slidesContainer.innerHTML = '';
                sliders.forEach((slider, index) => {
                    const img = document.createElement('img');
                    img.src = slider.image_url || '/images/Ningbo-Green-Belt-05_.jpg';
                    img.alt = slider.title || `Slide ${index + 1}`;
                    img.className = index === 0 ? 'active' : '';
                    img.id = `homeSlide${index + 1}`;
                    slidesContainer.appendChild(img);
                });
                
                // Update content for first slider
                if (sliders.length > 0) {
                    updateContent(0);
                }
            }

            function renderDefaultSlider() {
                slidesContainer.innerHTML = `
                    <img id="homeSlide1" src="/images/Ningbo-Green-Belt-05_.jpg" alt="Slide 1" class="active" />
                `;
                initSlider();
            }

            function updateContent(index) {
                const slider = sliders[index];
                if (!slider) return;
                
                currentSliderIndex = index;
                
                if (heroTitle) heroTitle.textContent = slider.title || 'আপনার স্বপ্নের বাড়ি';
                if (heroSubtitle) heroSubtitle.textContent = slider.subtitle || 'জলজোছনা প্রজেক্টে';
                if (heroDesc) heroDesc.textContent = slider.description || '';
                
                if (heroBtnPrimary) {
                    heroBtnPrimary.textContent = slider.primary_button_text || 'মূল্য দেখুন';
                    heroBtnPrimary.href = slider.primary_button_link || '#pricing';
                    heroBtnPrimary.style.display = slider.primary_button_text ? '' : 'none';
                }
                
                if (heroBtnSecondary) {
                    heroBtnSecondary.textContent = slider.secondary_button_text || 'যোগাযোগ করুন';
                    heroBtnSecondary.href = slider.secondary_button_link || '#contact';
                    heroBtnSecondary.style.display = slider.secondary_button_text ? '' : 'none';
                }
            }

            function initSlider() {
                const slides = Array.from(document.querySelectorAll('#homeSlides img'));
                if (!slides.length || !dotsWrap || !prev || !next) return;
                
                dotsWrap.innerHTML = '';
                
                function setActive(i) {
                    slides.forEach((im, k) => im.classList.toggle('active', k === i));
                    const dots = Array.from(dotsWrap.children);
                    dots.forEach((d, k) => d.classList.toggle('active', k === i));
                    idx = i;
                    updateContent(i);
                }
                
                slides.forEach((_, i) => {
                    const d = document.createElement('div');
                    d.className = 'slider-dot' + (i === 0 ? ' active' : '');
                    d.addEventListener('click', () => { setActive(i); restart(); });
                    dotsWrap.appendChild(d);
                });
                
                function go(n) { setActive((idx + n + slides.length) % slides.length); }
                function restart() { clearInterval(timer); timer = setInterval(() => go(1), 5000); }
                prev.addEventListener('click', () => { go(-1); restart(); });
                next.addEventListener('click', () => { go(1); restart(); });
                restart();
            }

            // Load sliders on page load
            loadHeroSliders();
            
            // Listen for updates from dashboard
            window.addEventListener('storage', function(e) {
                if (e.key === 'refreshHeroSlider') {
                    loadHeroSliders();
                }
            });
            
            // Reload sliders every 30 seconds
            setInterval(loadHeroSliders, 30000);
        })();
    </script>
</section>
<div class="green-shape-bottom"></div>