# Joljochna Deployment Package

## 📦 Package Contents

This deployment package contains everything needed to deploy the Joljochna real estate website to production hosting.

### Core Files Structure
```
joljochna/
├── app/                          # Application logic
├── bootstrap/                    # Framework bootstrap
├── config/                       # Configuration files
├── database/
│   ├── migrations/              # Database migrations
│   ├── seeders/                 # Data seeders
│   └── finaljoljochna_production.sql  # 🔥 Import this!
├── public/                       # Public web root
│   ├── assets/                  # CSS, JS, Images
│   ├── images/                  # Site images
│   ├── index.php                # Entry point
│   └── .htaccess                # Apache config
├── resources/                    # Views & assets
├── routes/                       # Application routes
├── storage/                      # File storage & logs
├── vendor/                       # Dependencies
├── .htaccess                     # Root redirect
├── .env.production              # 🔥 Production config template
├── deploy.sh                     # 🔥 Deployment script
└── backup.sh                     # Backup script
```

## 🚀 Quick Deployment Steps

### 1. Prepare Hosting
- PHP 8.1+ with required extensions
- MySQL/MariaDB database
- SSL certificate (HTTPS)
- SSH access (recommended)

### 2. Upload Files
Upload ALL files to your hosting directory:
- Via FTP/SFTP
- Or Git clone/pull
- Or File Manager

### 3. Database Setup
```sql
CREATE DATABASE Finaljoljochna CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
Import: `database/finaljoljochna_production.sql`

### 4. Configure Environment
```bash
# Rename and edit
cp .env.production .env
nano .env  # Update database credentials and domain
```

### 5. Run Deployment Script
```bash
bash deploy.sh
```

That's it! Your site should be live.

## 📋 Essential Files for Deployment

### Must Upload
- ✅ All application files (app/, config/, resources/, routes/)
- ✅ public/ directory (entire)
- ✅ vendor/ directory (Composer dependencies)
- ✅ storage/ directory structure
- ✅ .htaccess files (root and public/)
- ✅ database/finaljoljochna_production.sql

### Configure Before Use
- 🔧 .env.production → rename to .env and configure
- 🔧 Database credentials
- 🔧 APP_URL with your actual domain

### Optional (Recommended)
- 📄 deploy.sh (automated deployment)
- 📄 backup.sh (automated backups)
- 📄 DEPLOYMENT_GUIDE.md (detailed instructions)
- 📄 DEPLOYMENT_CHECKLIST.md (step-by-step checklist)

## 🔒 Security Checklist

Before going live:
- [ ] APP_DEBUG=false in .env
- [ ] APP_ENV=production
- [ ] Strong database password
- [ ] HTTPS enabled
- [ ] .env file secured (not web accessible)
- [ ] Storage permissions set (755)
- [ ] Admin password changed

## 💾 Database Information

**Database Name:** `Finaljoljochna`
**Tables:** 19 tables
**Data Included:** 
- Admin user account (1)
- Footer settings
- System configuration

**To Import:**
```bash
mysql -u username -p Finaljoljochna < database/finaljoljochna_production.sql
```

## 🛠️ Server Requirements

### PHP Extensions Required
- BCMath PHP Extension
- Ctype PHP Extension
- Fileinfo PHP Extension
- JSON PHP Extension
- Mbstring PHP Extension
- OpenSSL PHP Extension
- PDO PHP Extension
- Tokenizer PHP Extension
- XML PHP Extension
- cURL Extension

### Minimum Specifications
- PHP: 8.1 or higher
- MySQL: 5.7+ or MariaDB 10.3+
- Memory: 128MB minimum
- Disk Space: 500MB+

## 📁 Directory Permissions

Set these permissions after upload:
```bash
chmod -R 755 storage
chmod -R 755 bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

## 🌐 Website Features

### Frontend (Public)
- Multi-language support (Bengali/English)
- Responsive design (Mobile/Tablet/Desktop)
- Hero slider with custom content
- About section
- Features showcase
- Pricing/Plot information
- Customer testimonials
- Project gallery
- Contact form
- Location with QR code
- Social media integration

### Backend (Admin Panel)
Access: `https://yourdomain.com/admin/login`

Manage:
- Hero slider content
- About section
- Features & amenities
- Pricing tables
- Testimonials
- Project information
- Contact form submissions
- Booking requests
- Footer settings
- Social media links
- Site translations

## 📧 Configuration After Deployment

### 1. Admin Access
- URL: `https://yourdomain.com/admin/login`
- Check database `users` table for credentials
- Change password immediately after first login

### 2. Email Settings (Optional)
Update in .env:
```env
MAIL_MAILER=smtp
MAIL_HOST=your-smtp-host
MAIL_PORT=587
MAIL_USERNAME=your-email
MAIL_PASSWORD=your-password
```

### 3. Domain Configuration
Update in .env:
```env
APP_URL=https://yourdomain.com
```

## 🔄 Updating The Site

### Content Updates
Use admin panel at `/admin/login`

### Code Updates
1. Upload new files
2. Run: `bash deploy.sh`
3. Test changes

### Database Updates
1. Backup first: `bash backup.sh`
2. Run migrations: `php artisan migrate --force`

## 💡 Common Issues & Solutions

### Issue: 500 Internal Server Error
**Solution:**
```bash
chmod -R 755 storage bootstrap/cache
php artisan config:clear
```

### Issue: Database Connection Error
**Solution:**
- Check DB credentials in .env
- Verify DB user has all privileges
- Ensure DB_HOST is correct (usually 'localhost')

### Issue: Images Not Loading
**Solution:**
```bash
php artisan storage:link
chmod -R 755 storage
```

### Issue: White Screen
**Solution:**
- Set APP_DEBUG=true temporarily
- Check storage/logs/laravel.log
- Verify .htaccess files exist

## 📞 Support

**Documentation:**
- DEPLOYMENT_GUIDE.md - Detailed deployment guide
- DEPLOYMENT_CHECKLIST.md - Step-by-step checklist
- README.md - Project overview

**Logs Location:**
- `storage/logs/laravel.log`

## 🔐 Security Notes

1. **Never commit .env to Git** - Contains sensitive credentials
2. **Use strong passwords** - For database and admin accounts
3. **Enable HTTPS** - SSL certificate required for production
4. **Regular backups** - Use included backup.sh script
5. **Keep updated** - Monitor Laravel security updates

## 📦 Package Version

**Project:** Joljochna Real Estate Website
**Framework:** Laravel 12.36.1
**PHP:** 8.4.12
**Database:** Finaljoljochna
**Package Date:** November 12, 2025

---

## 🎯 Deployment Success Indicators

Your deployment is successful when:
- ✅ Homepage loads without errors
- ✅ Admin panel accessible
- ✅ All images displaying
- ✅ Forms working (contact, booking)
- ✅ Language switcher functioning
- ✅ Mobile responsive design working
- ✅ HTTPS enabled (green padlock)
- ✅ No console errors in browser

---

**Ready to Deploy!** 🚀

Follow DEPLOYMENT_CHECKLIST.md for detailed step-by-step instructions.

